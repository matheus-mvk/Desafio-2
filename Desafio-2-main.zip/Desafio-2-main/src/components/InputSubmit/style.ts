import styled from "styled-components";

const InputSub = styled.input`
    height: 7%;
    width: 20%;
    position: fixed;
`;

export {InputSub};